package onlinecurriculum.model;

public class OnlineCurriculumDBBean {

}
