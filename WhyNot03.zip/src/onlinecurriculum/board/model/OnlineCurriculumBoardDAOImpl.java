package onlinecurriculum.board.model;

import java.util.List;

public class OnlineCurriculumBoardDAOImpl implements OnlineCurriculumBoardDAO {

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<OnlineCurriculumBoardDBBean> list(int startRow, int endRow) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void count(int num) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public OnlineCurriculumBoardDBBean getBoard(int num) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void insertBoard(OnlineCurriculumBoardDBBean dto, int num) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteBoard(OnlineCurriculumBoardDBBean dto, int num) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateBoard(OnlineCurriculumBoardDBBean dto, int num) {
		// TODO Auto-generated method stub
		
	}

}
