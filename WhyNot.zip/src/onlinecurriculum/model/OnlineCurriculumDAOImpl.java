package onlinecurriculum.model;

import java.util.List;

public class OnlineCurriculumDAOImpl implements OnlineCurriculumDAO {

	@Override
	public OnlineCurriculumDBBean getCurriculum(int num) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<OnlineCurriculumDAO> listCurriculum() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void insertCurriculum(OnlineCurriculumDBBean dto, int num) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateCurriculum(OnlineCurriculumDBBean dto, int num) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteCurriculum(OnlineCurriculumDBBean dto, int num) {
		// TODO Auto-generated method stub
		
	}

}
