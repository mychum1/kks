package onlinecurriculum.board.model;

import java.util.List;


public class OnlineCurriculumBoardDBBean {

}
