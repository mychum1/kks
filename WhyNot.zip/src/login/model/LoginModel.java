package login.model;

public class LoginModel {
	private String id;
	private String password;
}
