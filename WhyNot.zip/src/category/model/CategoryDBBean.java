package category.model;

//CategoryDTO
public class CategoryDBBean { 
}
