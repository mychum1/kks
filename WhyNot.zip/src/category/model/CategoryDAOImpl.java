package category.model;

import java.util.List;

public class CategoryDAOImpl implements CategoryDAO {

	@Override
	public CategoryDBBean getCategory(int ctnum) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<CategoryDBBean> ListCategory() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void insertCategory(CategoryDBBean dto) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteCategory(int ctnum) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateCategory(int ctnum) {
		// TODO Auto-generated method stub
		
	}

}
